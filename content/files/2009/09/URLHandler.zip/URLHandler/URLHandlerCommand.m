#import "URLHandlerCommand.h"

/*
 TODO:
 - make autoquit configurable so it can take a timeout value
 - configurable exposure of scheme's
 - path control
 - config file? 
 - Do we need an icon?
*/

@implementation URLHandlerCommand

- (id)performDefaultImplementation {
	
    NSString *urlString = [self directParameter];
    NSURL 	 *url = [NSURL URLWithString: urlString];
    
    // Log what we got
    NSLog(@"url = %@", urlString);
	
    // Launch <protocol>_handler script in path
    NSTask *task = [NSTask new];
    NSString *script = [NSString stringWithFormat:@"~/bin/%@_handler",[url scheme]];
    NSLog(@"launchtarget = %@", script);
    [task setLaunchPath:script];
    
    // Give the URI-string as parameter to that script
    [task setArguments:[NSArray arrayWithObject:urlString]];
    
    // Catch stdout / stderr
    [task setStandardOutput:[NSPipe pipe]];
    [task setStandardError:[task standardOutput]];
    
    // Run it
    [task launch];
    
    // Log the output, if any
    NSData* output = [[[task standardOutput] fileHandleForReading] readDataToEndOfFile];
    NSString* out_string = [[[NSString alloc] initWithData:output encoding:NSUTF8StringEncoding] autorelease];
    NSLog(@"%@",out_string);
    
	// If we are not there we cant do no harm, so quit.
    [[NSApplication sharedApplication] terminate:nil];
    
    return nil;
}

@end
