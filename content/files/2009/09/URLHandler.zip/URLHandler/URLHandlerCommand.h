#import <Foundation/Foundation.h>


@interface URLHandlerCommand : NSScriptCommand {}

@end
